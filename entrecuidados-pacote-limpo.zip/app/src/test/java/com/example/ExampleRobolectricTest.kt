package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.FeelingType
import com.example.viewmodel.EntreCuidadosViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read EntreCuidados strings from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("EntreCuidados", context.getString(R.string.app_name))
        assertEquals(
            "Cuidar de quem cuida também é saúde.",
            context.getString(R.string.app_slogan)
        )
    }

    @Test
    fun `record self reflection updates session state without diagnosis`() {
        val vm = EntreCuidadosViewModel()
        vm.recordFeelingReflection(FeelingType.CANSADO, "Plantão intenso hoje")
        val state = vm.uiState.value
        assertEquals(1, state.sessionReflections.size)
        assertEquals(FeelingType.CANSADO, state.latestFeedbackFeeling)
        assertTrue(state.latestFeedbackFeeling!!.welcomingFeedback.isNotBlank())
    }
}
