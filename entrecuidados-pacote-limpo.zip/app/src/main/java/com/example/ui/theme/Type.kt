package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val PoppinsFontFamily = FontFamily(
    Font(R.font.poppins, FontWeight.Normal),
    Font(R.font.poppins, FontWeight.Medium),
    Font(R.font.poppins, FontWeight.SemiBold),
    Font(R.font.poppins, FontWeight.Bold),
)

val NunitoSansFontFamily = FontFamily(
    Font(R.font.nunito_sans, FontWeight.Normal),
    Font(R.font.nunito_sans, FontWeight.Medium),
    Font(R.font.nunito_sans, FontWeight.SemiBold),
    Font(R.font.nunito_sans, FontWeight.Bold),
)

fun buildEntreCuidadosTypography(scaleMultiplier: Float = 1.0f): Typography {
    return Typography(
        displaySmall = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (32 * scaleMultiplier).sp,
            lineHeight = (40 * scaleMultiplier).sp,
            letterSpacing = (-0.25).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (26 * scaleMultiplier).sp,
            lineHeight = (34 * scaleMultiplier).sp,
        ),
        headlineSmall = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (22 * scaleMultiplier).sp,
            lineHeight = (30 * scaleMultiplier).sp,
        ),
        titleLarge = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (19 * scaleMultiplier).sp,
            lineHeight = (26 * scaleMultiplier).sp,
        ),
        titleMedium = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (16 * scaleMultiplier).sp,
            lineHeight = (23 * scaleMultiplier).sp,
            letterSpacing = 0.1.sp
        ),
        titleSmall = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (14 * scaleMultiplier).sp,
            lineHeight = (20 * scaleMultiplier).sp,
            letterSpacing = 0.1.sp
        ),
        bodyLarge = TextStyle(
            fontFamily = NunitoSansFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (16 * scaleMultiplier).sp,
            lineHeight = (25 * scaleMultiplier).sp,
            letterSpacing = 0.2.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = NunitoSansFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (14.5f * scaleMultiplier).sp,
            lineHeight = (22 * scaleMultiplier).sp,
            letterSpacing = 0.2.sp
        ),
        bodySmall = TextStyle(
            fontFamily = NunitoSansFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (12.5f * scaleMultiplier).sp,
            lineHeight = (18 * scaleMultiplier).sp,
            letterSpacing = 0.3.sp
        ),
        labelLarge = TextStyle(
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (14 * scaleMultiplier).sp,
            lineHeight = (20 * scaleMultiplier).sp,
            letterSpacing = 0.15.sp
        ),
        labelMedium = TextStyle(
            fontFamily = NunitoSansFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (12 * scaleMultiplier).sp,
            lineHeight = (16 * scaleMultiplier).sp,
            letterSpacing = 0.4.sp
        ),
        labelSmall = TextStyle(
            fontFamily = NunitoSansFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (11 * scaleMultiplier).sp,
            lineHeight = (15 * scaleMultiplier).sp,
            letterSpacing = 0.4.sp
        )
    )
}

val Typography = buildEntreCuidadosTypography(1.0f)
