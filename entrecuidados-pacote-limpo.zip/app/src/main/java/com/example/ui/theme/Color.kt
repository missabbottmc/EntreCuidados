package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Oficial EntreCuidados
val DeepGreen = Color(0xFF123C36)       // Verde profundo (#123C36)
val SoftGreen = Color(0xFF6E9C88)       // Verde suave (#6E9C88)
val MistGreen = Color(0xFFE6F1E9)       // Verde névoa (#E6F1E9)
val WarmBeige = Color(0xFFF5F1E9)       // Bege (#F5F1E9)
val Terracotta = Color(0xFFD99B82)      // Terracota (#D99B82)
val PureWhite = Color(0xFFFFFFFF)       // Branco (#FFFFFF)

// Tons de suporte derivados para contraste e acessibilidade WCAG AA/AAA
val DeepGreenDark = Color(0xFF0B2622)
val DeepGreenSurface = Color(0xFF17453E)
val SoftGreenContainerDark = Color(0xFF244D41)
val TerracottaDark = Color(0xFF5C3120)
val TerracottaLight = Color(0xFFF9E6DE)
val InkText = Color(0xFF102A26)
val MutedGreenText = Color(0xFF3E5E57)
val OutlineSage = Color(0xFFB5CEC2)
val UrgentTerracotta = Color(0xFFB85637)
