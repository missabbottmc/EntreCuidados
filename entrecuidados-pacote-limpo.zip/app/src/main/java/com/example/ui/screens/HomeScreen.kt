package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.EntreCuidadosLogoMark
import com.example.ui.navigation.AppRoutes
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftGreen
import com.example.ui.theme.Terracotta
import com.example.viewmodel.EntreCuidadosUiState

private data class HomeShortcutItem(
    val titleRes: Int,
    val descRes: Int,
    val icon: ImageVector,
    val accentBg: Color,
    val accentIcon: Color,
    val route: String,
    val testTag: String,
    val badgeText: String? = null
)

@Composable
fun HomeScreen(
    uiState: EntreCuidadosUiState,
    onNavigate: (String) -> Unit
) {
    val shortcuts = listOf(
        HomeShortcutItem(
            titleRes = R.string.shortcut_feelings_title,
            descRes = R.string.shortcut_feelings_desc,
            icon = Icons.Outlined.FavoriteBorder,
            accentBg = Terracotta.copy(alpha = 0.22f),
            accentIcon = DeepGreen,
            route = AppRoutes.ROUTE_FEELINGS,
            testTag = "home_shortcut_sentimentos",
            badgeText = "Autorreflexão"
        ),
        HomeShortcutItem(
            titleRes = R.string.shortcut_pause_title,
            descRes = R.string.shortcut_pause_desc,
            icon = Icons.Outlined.SelfImprovement,
            accentBg = SoftGreen.copy(alpha = 0.22f),
            accentIcon = DeepGreen,
            route = AppRoutes.ROUTE_PAUSE,
            testTag = "home_shortcut_pausa",
            badgeText = "Respiração e descanso"
        ),
        HomeShortcutItem(
            titleRes = R.string.shortcut_library_title,
            descRes = R.string.shortcut_library_desc,
            icon = Icons.Outlined.AutoStories,
            accentBg = SoftGreen.copy(alpha = 0.18f),
            accentIcon = DeepGreen,
            route = AppRoutes.ROUTE_LIBRARY,
            testTag = "home_shortcut_biblioteca",
            badgeText = "7 categorias educativas"
        ),
        HomeShortcutItem(
            titleRes = R.string.shortcut_chat_title,
            descRes = R.string.shortcut_chat_desc,
            icon = Icons.Outlined.ChatBubbleOutline,
            accentBg = Terracotta.copy(alpha = 0.18f),
            accentIcon = DeepGreen,
            route = AppRoutes.ROUTE_SUPPORT_CHAT,
            testTag = "home_shortcut_acolhimento",
            badgeText = "Simulação acadêmica"
        ),
        HomeShortcutItem(
            titleRes = R.string.shortcut_network_title,
            descRes = R.string.shortcut_network_desc,
            icon = Icons.Outlined.Handshake,
            accentBg = DeepGreen.copy(alpha = 0.12f),
            accentIcon = DeepGreen,
            route = AppRoutes.ROUTE_SUPPORT_NETWORK,
            testTag = "home_shortcut_rede_apoio",
            badgeText = "UBS • CAPS • CEREST"
        )
    )

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Cabeçalho de boas-vindas na Página Inicial
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EntreCuidadosLogoMark(size = 46.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = uiState.selectedRole.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onNavigate(AppRoutes.ROUTE_PROFILE) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Spa,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Acolher",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Card Hero Principal: "Olá! Como podemos acolher você hoje?"
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(
                        containerColor = DeepGreen,
                        contentColor = PureWhite
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp)
                    ) {
                        Surface(
                            color = Terracotta.copy(alpha = 0.25f),
                            shape = CircleShape
                        ) {
                            Text(
                                text = stringResource(R.string.app_slogan),
                                style = MaterialTheme.typography.labelMedium,
                                color = Terracotta,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = stringResource(R.string.home_greeting_title),
                            style = MaterialTheme.typography.headlineSmall,
                            color = PureWhite
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "“${stringResource(R.string.central_concept)}”",
                            style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                            color = PureWhite.copy(alpha = 0.88f)
                        )
                    }
                }
            }

            // Resumo suave se houver autorreflexão recente na sessão
            if (uiState.sessionReflections.isNotEmpty()) {
                val latest = uiState.sessionReflections.first()
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.medium)
                            .clickable { onNavigate(AppRoutes.ROUTE_FEELINGS) },
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Seu registro recente nesta sessão (${latest.timeFormatted})",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Sentindo-se: ${latest.feeling.label}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Abrir autorreflexão",
                                tint = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }
            }

            // Seção de Atalhos Obrigatórios
            item {
                Text(
                    text = stringResource(R.string.home_shortcuts_section),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(shortcuts.size) { index ->
                val item = shortcuts[index]
                ShortcutCard(
                    item = item,
                    onClick = { onNavigate(item.route) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ShortcutCard(
    item: HomeShortcutItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag(item.testTag),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(item.accentBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                if (item.badgeText != null) {
                    Text(
                        text = item.badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }
                Text(
                    text = stringResource(item.titleRes),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = stringResource(item.descRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = stringResource(item.titleRes),
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
