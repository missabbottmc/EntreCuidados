package com.example.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.EntreCuidadosLogoMark
import com.example.ui.navigation.AppRoutes
import com.example.ui.navigation.BottomNavItems
import com.example.ui.screens.FeelingsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryDetailScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PauseScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SupportChatScreen
import com.example.ui.screens.SupportNetworkScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.EntreCuidadosTheme
import com.example.viewmodel.EntreCuidadosViewModel

@Composable
fun EntreCuidadosApp(
    viewModel: EntreCuidadosViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()

    EntreCuidadosTheme(
        darkTheme = uiState.darkModeEnabled,
        largeFontComfort = uiState.largeFontComfort
    ) {
        EntreCuidadosNavigationShell(
            navController = navController,
            viewModel = viewModel
        )
    }
}

@Composable
private fun EntreCuidadosNavigationShell(
    navController: NavHostController,
    viewModel: EntreCuidadosViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showMainNavigation = currentRoute != null && currentRoute != AppRoutes.ROUTE_WELCOME

    fun navigateToBottomTab(route: String) {
        navController.navigate(route) {
            popUpTo(AppRoutes.ROUTE_HOME) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun navigateSmart(route: String) {
        val isBottomTab = BottomNavItems.any { it.route == route }
        if (route == AppRoutes.ROUTE_WELCOME) {
            navController.navigate(AppRoutes.ROUTE_WELCOME) {
                launchSingleTop = true
            }
        } else if (isBottomTab) {
            navigateToBottomTab(route)
        } else {
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (showMainNavigation && !useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 4.dp,
                        modifier = Modifier.testTag("bottom_navigation_bar")
                    ) {
                        BottomNavItems.forEach { item ->
                            val isSelected = navBackStackEntry?.destination?.hierarchy?.any {
                                it.route == item.route ||
                                    (item.route == AppRoutes.ROUTE_LIBRARY && it.route == AppRoutes.ROUTE_LIBRARY_DETAIL)
                            } == true

                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { navigateToBottomTab(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showMainNavigation && useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        header = {
                            Spacer(modifier = Modifier.height(8.dp))
                            EntreCuidadosLogoMark(size = 42.dp)
                            Spacer(modifier = Modifier.height(8.dp))
                        },
                        modifier = Modifier.testTag("side_navigation_rail")
                    ) {
                        BottomNavItems.forEach { item ->
                            val isSelected = navBackStackEntry?.destination?.hierarchy?.any {
                                it.route == item.route ||
                                    (item.route == AppRoutes.ROUTE_LIBRARY && it.route == AppRoutes.ROUTE_LIBRARY_DETAIL)
                            } == true

                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { navigateToBottomTab(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.ROUTE_WELCOME,
                        enterTransition = { fadeIn(animationSpec = tween(220)) },
                        exitTransition = { fadeOut(animationSpec = tween(180)) },
                        popEnterTransition = { fadeIn(animationSpec = tween(220)) },
                        popExitTransition = { fadeOut(animationSpec = tween(180)) }
                    ) {
                        composable(AppRoutes.ROUTE_WELCOME) {
                            WelcomeScreen(
                                onStartClick = {
                                    navController.navigate(AppRoutes.ROUTE_HOME) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            inclusive = true
                                        }
                                        launchSingleTop = true
                                    }
                                }
                            )
                        }

                        composable(AppRoutes.ROUTE_HOME) {
                            HomeScreen(
                                uiState = uiState,
                                onNavigate = { route -> navigateSmart(route) }
                            )
                        }

                        composable(AppRoutes.ROUTE_LIBRARY) {
                            LibraryScreen(
                                onOpenCategory = { catId ->
                                    navController.navigate(AppRoutes.libraryDetailRoute(catId))
                                },
                                onNavigateBack = if (navController.previousBackStackEntry != null) {
                                    { navigateToBottomTab(AppRoutes.ROUTE_HOME) }
                                } else {
                                    null
                                }
                            )
                        }

                        composable(
                            route = AppRoutes.ROUTE_LIBRARY_DETAIL,
                            arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val categoryId = backStackEntry.arguments?.getString("categoryId") ?: "ansiedade"
                            LibraryDetailScreen(
                                categoryId = categoryId,
                                onNavigateBack = { navController.navigateUp() },
                                onNavigateToRoute = { route -> navigateSmart(route) }
                            )
                        }

                        composable(AppRoutes.ROUTE_SUPPORT_CHAT) {
                            SupportChatScreen(
                                uiState = uiState,
                                onSendMessage = viewModel::sendChatMessage,
                                onResetChat = viewModel::resetChatConversation,
                                onNavigateToRoute = { route -> navigateSmart(route) },
                                onNavigateBack = if (navController.previousBackStackEntry != null) {
                                    { navigateToBottomTab(AppRoutes.ROUTE_HOME) }
                                } else {
                                    null
                                }
                            )
                        }

                        composable(AppRoutes.ROUTE_FEELINGS) {
                            FeelingsScreen(
                                uiState = uiState,
                                onSaveReflection = viewModel::recordFeelingReflection,
                                onClearReflections = viewModel::clearSessionReflections,
                                onNavigateToRoute = { route -> navigateSmart(route) },
                                onNavigateBack = { navController.navigateUp() }
                            )
                        }

                        composable(AppRoutes.ROUTE_PAUSE) {
                            PauseScreen(
                                uiState = uiState,
                                onNextReflectionPrompt = viewModel::nextReflectionQuestion,
                                onToggleMicroCare = viewModel::toggleMicroCare,
                                onNavigateBack = { navController.navigateUp() }
                            )
                        }

                        composable(AppRoutes.ROUTE_SUPPORT_NETWORK) {
                            SupportNetworkScreen(
                                onNavigateBack = { navController.navigateUp() }
                            )
                        }

                        composable(AppRoutes.ROUTE_PROFILE) {
                            ProfileScreen(
                                uiState = uiState,
                                onSelectRole = viewModel::updateRoleProfile,
                                onToggleDarkMode = viewModel::toggleDarkMode,
                                onToggleLargeFont = viewModel::toggleLargeFontComfort,
                                onNavigateToRoute = { route -> navigateSmart(route) }
                            )
                        }
                    }
                }
            }
        }
    }
}
