package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R

object AppRoutes {
    const val ROUTE_WELCOME = "welcome"
    const val ROUTE_HOME = "home"
    const val ROUTE_LIBRARY = "library"
    const val ROUTE_LIBRARY_DETAIL = "library/{categoryId}"
    const val ROUTE_SUPPORT_CHAT = "support_chat"
    const val ROUTE_FEELINGS = "feelings"
    const val ROUTE_PAUSE = "pause"
    const val ROUTE_SUPPORT_NETWORK = "support_network"
    const val ROUTE_PROFILE = "profile"

    fun libraryDetailRoute(categoryId: String): String = "library/$categoryId"
}

data class BottomNavItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

val BottomNavItems = listOf(
    BottomNavItem(
        route = AppRoutes.ROUTE_HOME,
        labelRes = R.string.nav_home,
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_inicio"
    ),
    BottomNavItem(
        route = AppRoutes.ROUTE_LIBRARY,
        labelRes = R.string.nav_library,
        selectedIcon = Icons.Filled.AutoStories,
        unselectedIcon = Icons.Outlined.AutoStories,
        testTag = "nav_biblioteca"
    ),
    BottomNavItem(
        route = AppRoutes.ROUTE_SUPPORT_CHAT,
        labelRes = R.string.nav_support,
        selectedIcon = Icons.Filled.ChatBubble,
        unselectedIcon = Icons.Outlined.ChatBubbleOutline,
        testTag = "nav_acolhimento"
    ),
    BottomNavItem(
        route = AppRoutes.ROUTE_PROFILE,
        labelRes = R.string.nav_profile,
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.PersonOutline,
        testTag = "nav_perfil"
    )
)
