package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftGreen
import com.example.ui.theme.Terracotta

/**
 * Logotipo vetorial minimalista EntreCuidados:
 * Combina um coração orgânico em terracota acolhido por duas mãos minimalistas em concha,
 * sobre fundo verde profundo, simbolizando cuidado e humanização.
 */
@Composable
fun EntreCuidadosLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    containerColor: Color = DeepGreen,
    handStrokeColor: Color = PureWhite,
    heartColor: Color = Terracotta,
    leafAccentColor: Color = SoftGreen
) {
    val logoCd = stringResource(R.string.cd_brand_logo)
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(containerColor)
            .semantics { contentDescription = logoCd },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.72f)) {
            val w = this.size.width
            val h = this.size.height

            // Halo suave em verde suave atrás do coração
            drawCircle(
                color = leafAccentColor.copy(alpha = 0.25f),
                radius = w * 0.34f,
                center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.42f)
            )

            // Coração central minimalista
            val heartPath = Path().apply {
                moveTo(w * 0.50f, h * 0.60f)
                cubicTo(
                    w * 0.24f, h * 0.43f,
                    w * 0.23f, h * 0.20f,
                    w * 0.38f, h * 0.20f
                )
                cubicTo(
                    w * 0.45f, h * 0.20f,
                    w * 0.50f, h * 0.26f,
                    w * 0.50f, h * 0.31f
                )
                cubicTo(
                    w * 0.50f, h * 0.26f,
                    w * 0.55f, h * 0.20f,
                    w * 0.62f, h * 0.20f
                )
                cubicTo(
                    w * 0.77f, h * 0.20f,
                    w * 0.76f, h * 0.43f,
                    w * 0.50f, h * 0.60f
                )
                close()
            }
            drawPath(path = heartPath, color = heartColor)

            // Mão esquerda acolhendo em concha
            val leftHandPath = Path().apply {
                moveTo(w * 0.14f, h * 0.45f)
                cubicTo(
                    w * 0.12f, h * 0.68f,
                    w * 0.28f, h * 0.84f,
                    w * 0.47f, h * 0.86f
                )
                moveTo(w * 0.22f, h * 0.58f)
                cubicTo(
                    w * 0.26f, h * 0.70f,
                    w * 0.36f, h * 0.76f,
                    w * 0.46f, h * 0.78f
                )
            }

            // Mão direita acolhendo em concha
            val rightHandPath = Path().apply {
                moveTo(w * 0.86f, h * 0.45f)
                cubicTo(
                    w * 0.88f, h * 0.68f,
                    w * 0.72f, h * 0.84f,
                    w * 0.53f, h * 0.86f
                )
                moveTo(w * 0.78f, h * 0.58f)
                cubicTo(
                    w * 0.74f, h * 0.70f,
                    w * 0.64f, h * 0.76f,
                    w * 0.54f, h * 0.78f
                )
            }

            val strokeStyle = Stroke(
                width = w * 0.068f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
            drawPath(path = leftHandPath, color = handStrokeColor, style = strokeStyle)
            drawPath(path = rightHandPath, color = handStrokeColor, style = strokeStyle)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntreCuidadosTopBar(
    title: String,
    onNavigateBack: (() -> Unit)? = null,
    trailingAction: @Composable (() -> Unit)? = null
) {
    CenterAlignedTopAppBar(
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
        },
        navigationIcon = {
            if (onNavigateBack != null) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("top_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_navigate_back),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        actions = {
            trailingAction?.invoke()
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = Color.Transparent
        )
    )
}

@Composable
fun EthicalNoticeBanner(
    text: String,
    modifier: Modifier = Modifier,
    isSimulationHighlight: Boolean = false
) {
    val containerColor = if (isSimulationHighlight) {
        MaterialTheme.colorScheme.tertiaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
    }
    val contentColor = if (isSimulationHighlight) {
        MaterialTheme.colorScheme.onTertiaryContainer
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = containerColor,
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(
            width = 1.dp,
            color = if (isSimulationHighlight) {
                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.6f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Icon(
                imageVector = if (isSimulationHighlight) Icons.Outlined.Info else Icons.Outlined.VerifiedUser,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = contentColor
                )
            }
        }
    }
}
