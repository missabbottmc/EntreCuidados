package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val EntreCuidadosLightColors = lightColorScheme(
    primary = DeepGreen,
    onPrimary = PureWhite,
    primaryContainer = MistGreen,
    onPrimaryContainer = DeepGreen,
    secondary = SoftGreen,
    onSecondary = PureWhite,
    secondaryContainer = MistGreen,
    onSecondaryContainer = DeepGreen,
    tertiary = Terracotta,
    onTertiary = DeepGreenDark,
    tertiaryContainer = TerracottaLight,
    onTertiaryContainer = TerracottaDark,
    background = WarmBeige,
    onBackground = InkText,
    surface = PureWhite,
    onSurface = InkText,
    surfaceVariant = MistGreen,
    onSurfaceVariant = MutedGreenText,
    outline = OutlineSage,
    outlineVariant = MistGreen,
    error = UrgentTerracotta,
    onError = PureWhite,
    errorContainer = TerracottaLight,
    onErrorContainer = TerracottaDark
)

private val EntreCuidadosDarkColors = darkColorScheme(
    primary = SoftGreen,
    onPrimary = DeepGreenDark,
    primaryContainer = SoftGreenContainerDark,
    onPrimaryContainer = MistGreen,
    secondary = MistGreen,
    onSecondary = DeepGreen,
    secondaryContainer = DeepGreenSurface,
    onSecondaryContainer = MistGreen,
    tertiary = Terracotta,
    onTertiary = DeepGreenDark,
    tertiaryContainer = TerracottaDark,
    onTertiaryContainer = TerracottaLight,
    background = DeepGreenDark,
    onBackground = WarmBeige,
    surface = DeepGreen,
    onSurface = PureWhite,
    surfaceVariant = DeepGreenSurface,
    onSurfaceVariant = MistGreen,
    outline = SoftGreen,
    outlineVariant = SoftGreenContainerDark,
    error = Terracotta,
    onError = DeepGreenDark,
    errorContainer = TerracottaDark,
    onErrorContainer = TerracottaLight
)

@Composable
fun EntreCuidadosTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    largeFontComfort: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) EntreCuidadosDarkColors else EntreCuidadosLightColors
    val typography = buildEntreCuidadosTypography(
        scaleMultiplier = if (largeFontComfort) 1.12f else 1.0f
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = EntreCuidadosShapes,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    EntreCuidadosTheme(darkTheme = darkTheme, content = content)
}
