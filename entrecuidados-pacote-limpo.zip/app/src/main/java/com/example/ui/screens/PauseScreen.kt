package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.EntreCuidadosContent
import com.example.model.PausePillarId
import com.example.ui.components.EntreCuidadosTopBar
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SoftGreen
import com.example.ui.theme.Terracotta
import com.example.viewmodel.EntreCuidadosUiState
import kotlinx.coroutines.delay

@Composable
fun PauseScreen(
    uiState: EntreCuidadosUiState,
    onNextReflectionPrompt: () -> Unit,
    onToggleMicroCare: (Int) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedPillar by rememberSaveable { mutableStateOf(PausePillarId.RESPIRACAO) }
    val currentDetail = remember(selectedPillar) {
        EntreCuidadosContent.pausePillars.first { it.pillar == selectedPillar }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            EntreCuidadosTopBar(
                title = stringResource(R.string.pause_title),
                onNavigateBack = onNavigateBack
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Ilustração de pausa consciente
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column {
                            Image(
                                painter = painterResource(id = R.drawable.img_pause_breathe),
                                contentDescription = "Ilustração serena convidando a uma pausa de respiração e descanso",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(145.dp)
                                    .clip(MaterialTheme.shapes.large),
                                contentScale = ContentScale.Crop
                            )
                            Text(
                                text = stringResource(R.string.pause_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }

                // Abas de seleção dos 5 pilares obrigatórios
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(PausePillarId.entries) { pillar ->
                            val selected = pillar == selectedPillar
                            FilterChip(
                                selected = selected,
                                onClick = { selectedPillar = pillar },
                                label = {
                                    Text(
                                        text = pillar.title,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                shape = CircleShape,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.testTag("pause_tab_${pillar.name.lowercase()}")
                            )
                        }
                    }
                }

                // Exercício interativo especial para Respiração Consciente ou Reflexão Pessoal
                if (selectedPillar == PausePillarId.RESPIRACAO) {
                    item {
                        GuidedBreathingCard()
                    }
                }

                if (selectedPillar == PausePillarId.REFLEXAO) {
                    item {
                        ReflectionDeckCard(
                            question = EntreCuidadosContent.reflectionQuestions[uiState.currentReflectionPromptIndex],
                            onNextQuestion = onNextReflectionPrompt
                        )
                    }
                }

                // Detalhes educativos e práticas do pilar selecionado
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = currentDetail.pillar.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentDetail.pillar.subtitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = currentDetail.intro,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (selectedPillar == PausePillarId.AUTOCUIDADO) {
                                    "Toque para marcar seus microcuidados de hoje:"
                                } else {
                                    "Práticas educativas sugeridas:"
                                },
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            currentDetail.practices.forEachIndexed { idx, practice ->
                                val isChecked = selectedPillar == PausePillarId.AUTOCUIDADO &&
                                    uiState.completedMicroCares.contains(idx)

                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(MaterialTheme.shapes.small)
                                        .then(
                                            if (selectedPillar == PausePillarId.AUTOCUIDADO) {
                                                Modifier.clickable { onToggleMicroCare(idx) }
                                            } else {
                                                Modifier
                                            }
                                        ),
                                    color = if (isChecked) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.background
                                    },
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (selectedPillar == PausePillarId.AUTOCUIDADO) {
                                            Icon(
                                                imageVector = if (isChecked) {
                                                    Icons.Outlined.CheckCircle
                                                } else {
                                                    Icons.Outlined.RadioButtonUnchecked
                                                },
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                        }
                                        Text(
                                            text = if (selectedPillar == PausePillarId.AUTOCUIDADO) {
                                                practice
                                            } else {
                                                "${idx + 1}. $practice"
                                            },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = MaterialTheme.shapes.small,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "“${currentDetail.keyReminder}”",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun GuidedBreathingCard() {
    var isRunning by rememberSaveable { mutableStateOf(false) }
    var phaseIndex by remember { mutableIntStateOf(0) } // 0 = Inspire (4s), 1 = Sustente (4s), 2 = Expire (6s)
    var secondsLeft by remember { mutableIntStateOf(4) }
    var completedCycles by rememberSaveable { mutableIntStateOf(0) }

    LaunchedEffect(isRunning) {
        if (!isRunning) {
            phaseIndex = 0
            secondsLeft = 4
            return@LaunchedEffect
        }
        while (isRunning) {
            val phaseDuration = when (phaseIndex) {
                0 -> 4
                1 -> 4
                else -> 6
            }
            for (remaining in phaseDuration downTo 1) {
                secondsLeft = remaining
                delay(1000L)
            }
            if (phaseIndex == 2) {
                completedCycles += 1
                phaseIndex = 0
            } else {
                phaseIndex += 1
            }
        }
    }

    val targetScale = when {
        !isRunning -> 0.62f
        phaseIndex == 0 -> 0.96f
        phaseIndex == 1 -> 0.96f
        else -> 0.56f
    }

    val animatedScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(
            durationMillis = if (phaseIndex == 2) 5600 else 3800,
            easing = FastOutSlowInEasing
        ),
        label = "breathing_scale"
    )

    val phaseLabel = when {
        !isRunning -> "Pronto para começar"
        phaseIndex == 0 -> "Inspire suavemente… ($secondsLeft s)"
        phaseIndex == 1 -> "Sustente com conforto… ($secondsLeft s)"
        else -> "Expire soltando os ombros… ($secondsLeft s)"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Guia de Respiração 4-4-6",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier.size(170.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val maxRadius = size.minDimension / 2f
                    drawCircle(
                        color = SoftGreen.copy(alpha = 0.28f),
                        radius = maxRadius * (animatedScale * 1.04f).coerceAtMost(1f)
                    )
                    drawCircle(
                        color = DeepGreen,
                        radius = maxRadius * (animatedScale * 0.82f)
                    )
                    drawCircle(
                        color = Terracotta.copy(alpha = 0.85f),
                        radius = maxRadius * 0.22f
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = phaseLabel,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center
            )

            if (completedCycles > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Ciclos concluídos nesta pausa: $completedCycles",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { isRunning = !isRunning },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("breathing_toggle_button"),
                shape = MaterialTheme.shapes.medium,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRunning) {
                        stringResource(R.string.breathing_pause)
                    } else {
                        stringResource(R.string.breathing_start)
                    }
                )
            }
        }
    }
}

@Composable
private fun ReflectionDeckCard(
    question: String,
    onNextQuestion: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Pergunta para pausa interna",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "“$question”",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onNextQuestion,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.testTag("next_reflection_question_button")
            ) {
                Icon(imageVector = Icons.Outlined.Autorenew, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sortear outra reflexão")
            }
        }
    }
}
