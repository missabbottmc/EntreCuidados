package com.example.model

import androidx.compose.ui.graphics.vector.ImageVector

data class LibraryCategory(
    val id: String,
    val title: String,
    val tag: String,
    val readingTime: String,
    val summary: String,
    val introduction: String,
    val attentionPointsTitle: String,
    val attentionPoints: List<String>,
    val careReflections: List<String>,
    val closingMessage: String,
    val icon: ImageVector
)

enum class FeelingType(
    val id: String,
    val label: String,
    val shortHint: String,
    val welcomingFeedback: String,
    val suggestedActionLabel: String,
    val suggestedRoute: String
) {
    BEM(
        id = "bem",
        label = "Bem",
        shortHint = "Equilíbrio, serenidade ou presença",
        welcomingFeedback = "Que bom perceber este momento de equilíbrio. Reconhecer os dias em que nos sentimos bem fortalece nossas reservas internas para seguir cuidando com leveza.",
        suggestedActionLabel = "Explorar Biblioteca de Autocuidado",
        suggestedRoute = "library/autocuidado"
    ),
    NEUTRO(
        id = "neutro",
        label = "Neutro",
        shortHint = "Estável, observando o ritmo do dia",
        welcomingFeedback = "Estar neutro também faz parte da vida cotidiana. Nem todo dia precisa ser extraordinário — permitir-se apenas estar presente já é um gesto de respeito consigo.",
        suggestedActionLabel = "Fazer uma Pausa Consciente",
        suggestedRoute = "pause"
    ),
    PREOCUPADO(
        id = "preocupado",
        label = "Preocupado",
        shortHint = "Mente acelerada com demandas ou incertezas",
        welcomingFeedback = "Na saúde e na formação acadêmica, carregamos muitas responsabilidades. Respire fundo: você não precisa resolver todas as demandas ao mesmo tempo.",
        suggestedActionLabel = "Praticar Respiração Consciente",
        suggestedRoute = "pause"
    ),
    DESANIMADO(
        id = "desanimado",
        label = "Desanimado",
        shortHint = "Baixa energia ou falta de entusiasmo",
        welcomingFeedback = "Sentir desânimo pede gentileza, não autocobrança. Acolha seu ritmo hoje e lembre-se de que compartilhar o que sente com pessoas e serviços de confiança pode aliviar o peso.",
        suggestedActionLabel = "Conversar no Acolhimento",
        suggestedRoute = "support_chat"
    ),
    SOBRECARREGADO(
        id = "sobrecarregado",
        label = "Sobrecarregado",
        shortHint = "Excesso de tarefas, plantões ou estudos",
        welcomingFeedback = "Reconhecer a sobrecarga é um sinal importante de autopercepção. Quem cuida também tem limites humanos e merece apoio institucional, pausas reais e escuta.",
        suggestedActionLabel = "Conhecer a Rede de Apoio",
        suggestedRoute = "support_network"
    ),
    CANSADO(
        id = "cansado",
        label = "Cansado",
        shortHint = "Fadiga física, mental ou emocional",
        welcomingFeedback = "O cansaço de quem dedica horas ao cuidado do outro é legítimo. Descansar não é falha de dedicação — é condição essencial para a sua própria saúde.",
        suggestedActionLabel = "Fazer uma Pausa para Cuidar",
        suggestedRoute = "pause"
    )
}

data class SessionReflectionEntry(
    val id: Long,
    val feeling: FeelingType,
    val optionalNote: String,
    val timeFormatted: String
)

data class ChatMessage(
    val id: Long,
    val text: String,
    val isFromUser: Boolean,
    val timestamp: String,
    val showSupportButtons: Boolean = false
)

enum class PausePillarId(val title: String, val subtitle: String) {
    RESPIRACAO("Respiração consciente", "Desacelere o sistema nervoso com ciclos suaves"),
    REFLEXAO("Reflexão pessoal", "Perguntas gentis para reconectar-se consigo"),
    LIMITES("Limites profissionais", "Cuidar sem anular suas próprias necessidades"),
    DESCANSO("Descanso", "Recuperação física, mental e sensorial pós-jornada"),
    AUTOCUIDADO("Autocuidado", "Pequenos gestos sustentáveis na rotina da saúde")
}

data class PausePillarDetail(
    val pillar: PausePillarId,
    val intro: String,
    val practices: List<String>,
    val keyReminder: String
)

data class SupportServiceInfo(
    val id: String,
    val acronymOrTitle: String,
    val fullName: String,
    val roleSummary: String,
    val howToAccess: String,
    val targetAudienceNote: String,
    val icon: ImageVector
)

enum class HealthRoleProfile(val label: String, val description: String) {
    ESTUDANTE("Estudante da Saúde", "Graduação, técnico ou estágio obrigatório"),
    PROFISSIONAL("Profissional da Saúde", "Atuação assistencial, clínica, hospitalar ou comunitária"),
    RESIDENTE("Residente / Pós-graduando", "Residência multiprofissional, médica ou pesquisa"),
    DOCENTE_GESTOR("Docente / Gestão em Saúde", "Ensino, preceptoria ou coordenação de equipes")
}
