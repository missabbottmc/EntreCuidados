package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.EntreCuidadosContent
import com.example.model.ChatMessage
import com.example.model.FeelingType
import com.example.model.HealthRoleProfile
import com.example.model.SessionReflectionEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EntreCuidadosUiState(
    val selectedRole: HealthRoleProfile = HealthRoleProfile.PROFISSIONAL,
    val darkModeEnabled: Boolean = false,
    val largeFontComfort: Boolean = false,
    val sessionReflections: List<SessionReflectionEntry> = emptyList(),
    val latestFeedbackFeeling: FeelingType? = null,
    val chatMessages: List<ChatMessage> = listOf(
        ChatMessage(
            id = 1L,
            text = "Olá! Que bom receber você aqui no EntreCuidados. Este é um espaço seguro de simulação acadêmica, pensado para oferecer escuta empática, sem pressa e sem julgamentos.",
            isFromUser = false,
            timestamp = "Agora"
        ),
        ChatMessage(
            id = 2L,
            text = "Como tem sido o seu dia nos estudos ou na rotina de cuidado em saúde? Você pode escrever livremente ou tocar em uma das sugestões abaixo.",
            isFromUser = false,
            timestamp = "Agora",
            showSupportButtons = true
        )
    ),
    val isAssistantTyping: Boolean = false,
    val completedMicroCares: Set<Int> = emptySet(),
    val currentReflectionPromptIndex: Int = 0
)

class EntreCuidadosViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(EntreCuidadosUiState())
    val uiState: StateFlow<EntreCuidadosUiState> = _uiState.asStateFlow()

    private fun currentFormattedTime(): String {
        val formatter = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
        return formatter.format(Date())
    }

    fun updateRoleProfile(role: HealthRoleProfile) {
        _uiState.update { it.copy(selectedRole = role) }
    }

    fun toggleDarkMode(enabled: Boolean) {
        _uiState.update { it.copy(darkModeEnabled = enabled) }
    }

    fun toggleLargeFontComfort(enabled: Boolean) {
        _uiState.update { it.copy(largeFontComfort = enabled) }
    }

    fun recordFeelingReflection(feeling: FeelingType, optionalNote: String) {
        val entry = SessionReflectionEntry(
            id = System.currentTimeMillis(),
            feeling = feeling,
            optionalNote = optionalNote.trim(),
            timeFormatted = currentFormattedTime()
        )
        _uiState.update { state ->
            state.copy(
                sessionReflections = listOf(entry) + state.sessionReflections,
                latestFeedbackFeeling = feeling
            )
        }
    }

    fun clearSessionReflections() {
        _uiState.update {
            it.copy(
                sessionReflections = emptyList(),
                latestFeedbackFeeling = null
            )
        }
    }

    fun sendChatMessage(rawText: String) {
        val cleanText = rawText.trim()
        if (cleanText.isEmpty()) return

        val time = currentFormattedTime()
        val userMsg = ChatMessage(
            id = System.currentTimeMillis(),
            text = cleanText,
            isFromUser = true,
            timestamp = time
        )

        _uiState.update { state ->
            state.copy(
                chatMessages = state.chatMessages + userMsg,
                isAssistantTyping = true
            )
        }

        viewModelScope.launch {
            delay(650L)
            val (replyText, showButtons) = EntreCuidadosContent.generateSimulatedEmpatheticReply(cleanText)
            val botMsg = ChatMessage(
                id = System.currentTimeMillis() + 1L,
                text = replyText,
                isFromUser = false,
                timestamp = currentFormattedTime(),
                showSupportButtons = showButtons
            )
            _uiState.update { state ->
                state.copy(
                    chatMessages = state.chatMessages + botMsg,
                    isAssistantTyping = false
                )
            }
        }
    }

    fun resetChatConversation() {
        _uiState.update {
            it.copy(
                chatMessages = EntreCuidadosUiState().chatMessages,
                isAssistantTyping = false
            )
        }
    }

    fun nextReflectionQuestion() {
        val total = EntreCuidadosContent.reflectionQuestions.size
        _uiState.update { state ->
            state.copy(currentReflectionPromptIndex = (state.currentReflectionPromptIndex + 1) % total)
        }
    }

    fun toggleMicroCare(index: Int) {
        _uiState.update { state ->
            val updated = if (state.completedMicroCares.contains(index)) {
                state.completedMicroCares - index
            } else {
                state.completedMicroCares + index
            }
            state.copy(completedMicroCares = updated)
        }
    }
}
