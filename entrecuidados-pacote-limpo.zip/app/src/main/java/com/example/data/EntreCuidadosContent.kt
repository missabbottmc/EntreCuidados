package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Air
import androidx.compose.material.icons.outlined.BatteryAlert
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.HealthAndSafety
import androidx.compose.material.icons.outlined.LocalHospital
import androidx.compose.material.icons.outlined.MedicalServices
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.Spa
import com.example.model.LibraryCategory
import com.example.model.PausePillarDetail
import com.example.model.PausePillarId
import com.example.model.SupportServiceInfo

object EntreCuidadosContent {

    val libraryCategories: List<LibraryCategory> = listOf(
        LibraryCategory(
            id = "ansiedade",
            title = "Ansiedade",
            tag = "Emoções e Alerta",
            readingTime = "3 min de leitura",
            summary = "Compreenda como o estado constante de vigilância afeta quem estuda e trabalha cuidando de vidas.",
            introduction = "A ansiedade é uma resposta humana natural diante de desafios e incertezas. No entanto, em rotinas marcadas por provas práticas, plantões, decisões rápidas e contato com a dor alheia, o estado de alerta pode permanecer ativado mesmo nos momentos de folga.",
            attentionPointsTitle = "Sinais educativos para observar com gentileza",
            attentionPoints = listOf(
                "Preocupação antecipatória constante com plantões, avaliações ou intercorrências.",
                "Sensação física de inquietação, tensão muscular nos ombros, taquicardia ou respiração curta.",
                "Dificuldade em 'desligar a mente' ao chegar em casa após o expediente ou estágio.",
                "Autocobrança excessiva por perfeição em cada procedimento ou estudo."
            ),
            careReflections = listOf(
                "Faça pausas breves de aterramento sensorial entre atendimentos ou blocos de estudo.",
                "Diferencie o que está sob seu alcance hoje daquilo que depende de toda uma equipe ou sistema.",
                "Quando a ansiedade trouxer sofrimento frequente ou prejuízo ao cotidiano, buscar psicoterapia é um passo seguro e recomendado."
            ),
            closingMessage = "Sentir ansiedade não diminui sua competência profissional ou acadêmica; revela que você é humano.",
            icon = Icons.Outlined.Air
        ),
        LibraryCategory(
            id = "estresse",
            title = "Estresse",
            tag = "Ritmo e Sobrecarga",
            readingTime = "3 min de leitura",
            summary = "Entenda os impactos do estresse acumulado na rotina da saúde e estratégias de regulação.",
            introduction = "Ambientes assistenciais e universitários envolvem estímulos intensos: ruídos, prazos, múltiplas tarefas simultâneas e alta responsabilidade ética. Quando a exigência ultrapassa repetidamente o tempo disponível para recuperação, o organismo sinaliza desgaste.",
            attentionPointsTitle = "Como o estresse costuma se manifestar",
            attentionPoints = listOf(
                "Irritabilidade atípica ou sensibilidade aumentada a pequenas mudanças na rotina.",
                "Alterações no sono (sono fragmentado ou sensação de acordar já cansado).",
                "Dificuldade de concentração e esquecimentos frequentes em tarefas simples.",
                "Cefaleias tensionais, desconfortos gastrointestinais e fadiga persistente."
            ),
            careReflections = listOf(
                "Inclua pequenos rituais de transição ao encerrar o turno (lavar o rosto com calma, trocar de roupa, ouvir uma música tranquila).",
                "Organize prioridades em listas realistas, evitando acumular metas inatingíveis em um único dia.",
                "Converse com colegas, preceptores ou redes de apoio sobre fluxos de trabalho mais sustentáveis."
            ),
            closingMessage = "Desacelerar por alguns minutos não é perda de tempo — é proteção para quem cuida.",
            icon = Icons.Outlined.Psychology
        ),
        LibraryCategory(
            id = "depressao",
            title = "Depressão",
            tag = "Acolhimento e Escuta",
            readingTime = "4 min de leitura",
            summary = "Informação ética e sem estigmas sobre tristeza persistente, perda de sentido e busca por cuidado.",
            introduction = "Na área da saúde, ainda existe o mito silencioso de que quem cuida deve ser sempre forte e inabalável. Esse tabu muitas vezes faz estudantes e trabalhadores silenciarem diante da tristeza profunda, da apatia ou da perda de prazer nas atividades que antes faziam sentido.",
            attentionPointsTitle = "Aspectos educativos de atenção",
            attentionPoints = listOf(
                "Humor entristecido, sensação de vazio ou perda de interesse que persiste por semanas.",
                "Fadiga intensa em que mesmo tarefas cotidianas básicas parecem exigir enorme esforço.",
                "Sentimentos recorrentes de culpa, inadequação ou retraimento do convívio social.",
                "Alterações importantes no apetite, no sono e na capacidade de planejar o futuro."
            ),
            careReflections = listOf(
                "Evite julgar seu sofrimento como 'falta de força de vontade'. Saúde mental merece o mesmo respeito que qualquer condição física.",
                "Rompa o isolamento: converse com alguém de confiança e procure avaliação especializada na Rede de Apoio (UBS, CAPS ou profissionais de saúde mental).",
                "Acompanhamento psicológico e médico adequado oferece acolhimento efetivo e recuperação."
            ),
            closingMessage = "Pedir ajuda profissional é um ato de coragem e de compromisso com a própria vida.",
            icon = Icons.Outlined.FavoriteBorder
        ),
        LibraryCategory(
            id = "trabalho",
            title = "Saúde mental no trabalho",
            tag = "Humanização Laboral",
            readingTime = "4 min de leitura",
            summary = "Relações de equipe, condições de trabalho, fadiga por compaixão e proteção ao trabalhador da saúde.",
            introduction = "O trabalho em saúde coloca profissionais em contato direto com vulnerabilidades humanas, jornadas noturnas, escalas complexas e desafios estruturais. Promover saúde mental no trabalho envolve tanto práticas individuais quanto ambientes institucionais éticos, seguros e colaborativos.",
            attentionPointsTitle = "Fatores psicossociais relevantes na assistência",
            attentionPoints = listOf(
                "Duplas jornadas, plantões sucessivos e escassez de pausas adequadas para descanso e alimentação.",
                "Fadiga por compaixão: desgaste emocional decorrente da exposição contínua à dor de pacientes e familiares.",
                "Comunicação ruidosa ou falta de espaços seguros de escuta entre equipes multiprofissionais.",
                "Necessidade de conhecer direitos e suporte em Saúde do Trabalhador (como o CEREST)."
            ),
            careReflections = listOf(
                "Fortaleça vínculos de cooperação e acolhimento mútuo entre colegas de plantão e equipe.",
                "Reconheça os limites do seu papel profissional e utilize canais institucionais de saúde ocupacional.",
                "Valorize pausas regulamentares durante a jornada como parte da segurança do cuidado."
            ),
            closingMessage = "Humanizar a saúde começa também pela valorização e proteção de quem trabalha nela.",
            icon = Icons.Outlined.MedicalServices
        ),
        LibraryCategory(
            id = "academica",
            title = "Saúde mental acadêmica",
            tag = "Formação e Estágios",
            readingTime = "3 min de leitura",
            summary = "Os desafios emocionais da graduação, cursos técnicos, estágios e residências na área da saúde.",
            introduction = "Ingressar e permanecer na formação em saúde envolve carga horária extensa, primeiras experiências diante da doença e da finitude, pressão por desempenho, conciliação financeira e transição para a vida profissional.",
            attentionPointsTitle = "Desafios frequentes na trajetória estudantil",
            attentionPoints = listOf(
                "Síndrome do impostor e medo constante de errar durante aulas práticas e estágios supervisionados.",
                "Privação de sono em semanas de provas, trabalhos acadêmicos e plantões curriculares.",
                "Distanciamento da família, lazer reduzido e comparações constantes com colegas.",
                "Impacto emocional dos primeiros atendimentos clínicos sem espaço de elaboração."
            ),
            careReflections = listOf(
                "Lembre-se de que você está em processo de aprendizagem — ninguém nasce sabendo cuidar.",
                "Procure os núcleos de apoio psicopedagógico e estudantil da sua instituição de ensino.",
                "Preserve momentos semanais de descanso, convivência afetiva e atividades fora do universo acadêmico."
            ),
            closingMessage = "Sua trajetória formativa importa, mas sua saúde e dignidade vêm sempre em primeiro lugar.",
            icon = Icons.Outlined.School
        ),
        LibraryCategory(
            id = "burnout",
            title = "Burnout",
            tag = "Esgotamento Ocupacional",
            readingTime = "4 min de leitura",
            summary = "Compreenda a síndrome do esgotamento relacionado ao trabalho e a importância da prevenção.",
            introduction = "Reconhecido pela Organização Mundial da Saúde como um fenômeno ocupacional, o Burnout resulta do estresse crônico no ambiente de trabalho que não foi adequadamente gerenciado — sendo historicamente frequente entre profissionais e residentes da saúde.",
            attentionPointsTitle = "Três dimensões descritas na literatura educativa",
            attentionPoints = listOf(
                "Exaustão emocional e física profunda: sensação de não ter mais energia disponível para doar.",
                "Distanciamento afetivo ou ceticismo defensivo em relação ao trabalho como tentativa inconsciente de autoproteção.",
                "Sensação de redução da realização profissional, mesmo diante de grande esforço diário."
            ),
            careReflections = listOf(
                "Não normalize o esgotamento extremo como 'parte natural da profissão'.",
                "A avaliação de Burnout deve ser feita exclusivamente por profissionais habilitados (médicos e psicólogos), considerando também o contexto laboral.",
                "Serviços como UBS, CAPS, CEREST e saúde ocupacional apoiam a orientação e o cuidado integral."
            ),
            closingMessage = "Reconhecer sinais precoces de esgotamento permite reconstruir limites e buscar suporte a tempo.",
            icon = Icons.Outlined.BatteryAlert
        ),
        LibraryCategory(
            id = "autocuidado",
            title = "Autocuidado",
            tag = "Prática Diária",
            readingTime = "3 min de leitura",
            summary = "Autocuidado possível e realista: longe de cobranças estéticas e perto da sua realidade.",
            introduction = "Autocuidado verdadeiro não é mais uma tarefa punitiva na agenda, nem depende de rotinas perfeitas. Trata-se de pequenas escolhas cotidianas de preservação física, emocional, relacional e ética que sustentam quem você é além do jaleco ou do crachá.",
            attentionPointsTitle = "Dimensões práticas de autocuidado integral",
            attentionPoints = listOf(
                "Corporal: hidratação durante o turno, alimentação nutritiva possível e respeito ao sono reparador.",
                "Emocional: dar nome ao que sente sem se julgar e permitir-se pedir colo ou escuta.",
                "Relacional: cultivar amizades, afeto familiar e espaços onde você não precise atuar como cuidador.",
                "Profissional: aprender a dizer 'não' a sobrecargas inseguras e respeitar o tempo de descanso."
            ),
            careReflections = listOf(
                "Qual é o menor gesto gentil que você pode oferecer a si mesmo nos próximos dez minutos?",
                "Beber um copo d'água com calma e alongar os ombros já inaugura uma pausa de cuidado.",
                "Cuidar de si fortalece a presença ética, mas acima de tudo honra o seu valor enquanto pessoa."
            ),
            closingMessage = "Entre cuidados, existe um cuidado que também precisa ser lembrado: o seu.",
            icon = Icons.Outlined.Spa
        )
    )

    val reflectionQuestions: List<String> = listOf(
        "Se um colega querido estivesse vivendo exatamente o seu dia hoje, que palavras gentis você diria a ele?",
        "Qual necessidade básica do seu corpo ou da sua mente pediu atenção hoje e ainda pode ser acolhida?",
        "O que você pode soltar hoje sabendo que já ofereceu o melhor cuidado possível dentro das suas condições?",
        "Quem ou qual atividade fora do trabalho/estudo costuma lembrar você de quem você é além da área da saúde?",
        "Qual pequeno limite saudável traria mais paz para a sua semana?"
    )

    val pausePillars: List<PausePillarDetail> = listOf(
        PausePillarDetail(
            pillar = PausePillarId.RESPIRACAO,
            intro = "A respiração ritmada envia sinais diretos de segurança ao sistema nervoso autônomo, ajudando a reduzir a tensão acumulada entre atendimentos ou estudos.",
            practices = listOf(
                "Apoie os dois pés no chão e solte suavemente os ombros.",
                "Inspire pelo nariz contando até 4 segundos.",
                "Sustente o ar com conforto por 4 segundos.",
                "Expire lentamente pela boca por 6 segundos, soltando a mandíbula."
            ),
            keyReminder = "Três ciclos conscientes já ajudam o corpo a sair do modo automático."
        ),
        PausePillarDetail(
            pillar = PausePillarId.REFLEXAO,
            intro = "Pausar para ouvir a si mesmo evita que emoções legítimas fiquem acumuladas em silêncio ao longo da semana.",
            practices = listOf(
                "Reconheça uma coisa difícil com a qual você lidou hoje sem minimizar seu esforço.",
                "Reconheça um pequeno gesto de humanidade que você ofereceu ou recebeu.",
                "Permita-se encerrar mentalmente o turno quando sair do local de estudo ou trabalho."
            ),
            keyReminder = "Autorreflexão não é autojulgamento: olhe para si com curiosidade e respeito."
        ),
        PausePillarDetail(
            pillar = PausePillarId.LIMITES,
            intro = "Estabelecer limites claros na saúde não significa indiferença; significa preservar condições éticas e humanas para continuar bem.",
            practices = listOf(
                "Evite responder mensagens de trabalho ou grupos acadêmicos não urgentes durante seu horário de sono.",
                "Comunique com clareza à equipe quando precisar de apoio em um procedimento ou demanda.",
                "Lembre-se: descansar na folga é um direito, não motivo de culpa."
            ),
            keyReminder = "Dizer 'sim' para o seu limite é proteger sua saúde mental a longo prazo."
        ),
        PausePillarDetail(
            pillar = PausePillarId.DESCANSO,
            intro = "Existem diferentes formas de descanso além de dormir: descanso mental, sensorial e emocional são essenciais após ambientes hospitalares ou salas de aula.",
            practices = listOf(
                "Descanso sensorial: reduza luzes fortes, telas e notificações por 15 minutos após o expediente.",
                "Descompressão física: tome um banho morno prestando atenção na temperatura da água.",
                "Higiene do sono: crie um intervalo tranquilo antes de deitar, longe de revisões de casos ou provas."
            ),
            keyReminder = "O descanso faz parte do ciclo biológico da vida — não precisa ser 'merecido' por exaustão."
        ),
        PausePillarDetail(
            pillar = PausePillarId.AUTOCUIDADO,
            intro = "Microcuidados sustentáveis cabem na rotina real de estudantes e profissionais de todas as áreas da saúde.",
            practices = listOf(
                "Beber água regularmente ao longo do turno ou aula.",
                "Fazer refeições sentado(a), respirando antes da primeira garfada.",
                "Alongar pescoço, punhos e coluna lombar entre atendimentos.",
                "Reservar tempo semanal para lazer, arte, natureza ou convívio afetivo."
            ),
            keyReminder = "Constância gentil vale muito mais do que metas rígidas."
        )
    )

    val supportServices: List<SupportServiceInfo> = listOf(
        SupportServiceInfo(
            id = "ubs",
            acronymOrTitle = "UBS",
            fullName = "Unidade Básica de Saúde (Atenção Primária - SUS)",
            roleSummary = "Porta de entrada preferencial do SUS para acolhimento integral, escuta qualificada, acompanhamento longitudinal e atuação de equipes multiprofissionais (eMulti).",
            howToAccess = "Procure a UBS mais próxima da sua residência levando documento com foto e Cartão Nacional de Saúde (SUS). Não é necessário agendamento prévio para acolhimento inicial.",
            targetAudienceNote = "Indicada para sofrimento emocional leve a moderado, orientação preventiva, cuidado contínuo e articulação com a rede.",
            icon = Icons.Outlined.LocalHospital
        ),
        SupportServiceInfo(
            id = "caps",
            acronymOrTitle = "CAPS",
            fullName = "Centro de Atenção Psicossocial",
            roleSummary = "Serviço público comunitário e de portas abertas do SUS, especializado no cuidado humanizado e territorial de pessoas em sofrimento psíquico intenso ou persistente (CAPS I, II, III e CAPS AD).",
            howToAccess = "Acesso direto por demanda espontânea (sem necessidade de encaminhamento prévio) ou articulado junto à UBS e hospitais da sua região.",
            targetAudienceNote = "Conta com equipe multiprofissional composta por psicólogos, psiquiatras, enfermeiros, assistentes sociais e terapeutas ocupacionais.",
            icon = Icons.Outlined.Groups
        ),
        SupportServiceInfo(
            id = "cerest",
            acronymOrTitle = "CEREST",
            fullName = "Centro de Referência em Saúde do Trabalhador",
            roleSummary = "Serviço especializado do SUS voltado à vigilância, prevenção, acolhimento técnico e orientação em agravos físicos e mentais relacionados ao trabalho — incluindo esgotamento e riscos psicossociais em trabalhadores da saúde.",
            howToAccess = "Consulte o CEREST regional ou municipal da sua cidade, ou solicite encaminhamento/orientação pela UBS, sindicato ou serviço de saúde ocupacional.",
            targetAudienceNote = "Fundamental para profissionais, técnicos e residentes que vivenciam adoecimento associado às condições laborais.",
            icon = Icons.Outlined.HealthAndSafety
        ),
        SupportServiceInfo(
            id = "institucional",
            acronymOrTitle = "Apoio Institucional e Universitário",
            fullName = "Núcleos Estudantis, Residências e Saúde Ocupacional",
            roleSummary = "Universidades, faculdades, escolas técnicas e hospitais frequentemente dispõem de Núcleos de Apoio Psicopedagógico/Estudantil (NAE/NAP), programas de mentoria e Serviços de Saúde do Trabalhador.",
            howToAccess = "Verifique junto à coordenação de curso, pró-reitoria de assuntos estudantis, comissão de residência (COREME/COREMU) ou setor de gestão de pessoas da sua instituição.",
            targetAudienceNote = "Espaços sensíveis às demandas específicas de estágios, avaliações, preceptoria e rotinas assistenciais.",
            icon = Icons.Outlined.AccountBalance
        ),
        SupportServiceInfo(
            id = "profissionais",
            acronymOrTitle = "Profissionais de Saúde Mental",
            fullName = "Psicólogos, Psiquiatras, Clínicas-Escola e Atendimento Social",
            roleSummary = "O acompanhamento individual ou grupal com psicólogos (CRP ativo) e médicos psiquiatras (CRM/RQE) oferece espaço sigiloso, ético e baseado em evidências para elaboração emocional e tratamento quando indicado.",
            howToAccess = "Além da rede pública (SUS) e convênios, universidades de Psicologia oferecem Clínicas-Escola gratuitas ou a valores sociais abertas à comunidade e estudantes.",
            targetAudienceNote = "Busque sempre profissionais devidamente registrados em seus conselhos de classe.",
            icon = Icons.Outlined.SelfImprovement
        )
    )

    val quickChatPrompts: List<String> = listOf(
        "Tive um plantão ou estágio exaustivo",
        "Sinto culpa quando tento descansar",
        "Estou ansioso(a) com tantas cobranças",
        "Quero orientações práticas de pausa",
        "Como encontrar apoio profissional?"
    )

    fun generateSimulatedEmpatheticReply(userMessage: String): Pair<String, Boolean> {
        val normalized = userMessage.lowercase()
        return when {
            normalized.contains("crise") ||
                normalized.contains("urgência") ||
                normalized.contains("urgencia") ||
                normalized.contains("morrer") ||
                normalized.contains("suic") ||
                normalized.contains("não aguento viver") ||
                normalized.contains("desespero") -> {
                Pair(
                    "Sinto muito que você esteja atravessando uma dor tão intensa agora. Sua vida e sua segurança são muito importantes, e você não precisa passar por isso sozinho(a). Como este espaço é apenas uma simulação acadêmica, peço com carinho que busque apoio humano imediato: ligue gratuitamente para o CVV no 188 (24h), acione o SAMU (192) ou procure a UPA / CAPS mais próximo. Toque abaixo para ver toda a Rede de Apoio.",
                    true
                )
            }
            normalized.contains("plantão") ||
                normalized.contains("plantao") ||
                normalized.contains("estágio") ||
                normalized.contains("estagio") ||
                normalized.contains("exaust") ||
                normalized.contains("cansad") -> {
                Pair(
                    "Parece que o seu dia exigiu muito de você física e emocionalmente. Lidar com a intensidade de plantões e estágios na saúde cansa de verdade. Antes de se cobrar qualquer outra tarefa, que tal permitir ao seu corpo alguns minutos de descompressão, um copo d'água e uma respiração mais lenta? Estou aqui se quiser contar como está se sentindo agora.",
                    true
                )
            }
            normalized.contains("culpa") ||
                normalized.contains("descans") ||
                normalized.contains("parar") -> {
                Pair(
                    "A culpa ao descansar é muito comum entre estudantes e profissionais da saúde, porque aprendemos a olhar sempre para a urgência do outro. Mas descansar não é descuido — é uma necessidade humana legítima. Respeitar suas pausas protege quem você é. Você conseguiu ter algum pequeno intervalo tranquilo hoje?",
                    false
                )
            }
            normalized.contains("ansios") ||
                normalized.contains("ansiedad") ||
                normalized.contains("cobranç") ||
                normalized.contains("prova") ||
                normalized.contains("sobrecarreg") -> {
                Pair(
                    "Quando muitas responsabilidades se acumulam ao mesmo tempo, é compreensível que a mente fique em estado constante de alerta. Vamos por partes, um passo de cada vez: você não precisa sustentar tudo sozinho(a). Se quiser, você pode experimentar nossa 'Pausa para cuidar' com respiração guiada ou explorar conteúdos educativos sobre manejo da sobrecarga.",
                    true
                )
            }
            normalized.contains("orientaç") ||
                normalized.contains("orientac") ||
                normalized.contains("pausa") ||
                normalized.contains("dica") -> {
                Pair(
                    "Claro! Algumas orientações acolhedoras para este momento:\n• Solte os ombros e faça 3 expirações longas.\n• Nomeie o que está sentindo sem se julgar.\n• Separe o que precisa ser feito hoje do que pode esperar.\n• Use os botões abaixo para abrir exercícios de Pausa ou conhecer a Rede de Apoio.",
                    true
                )
            }
            normalized.contains("apoio") ||
                normalized.contains("profissional") ||
                normalized.contains("psicólog") ||
                normalized.contains("psicolog") ||
                normalized.contains("ajuda") ||
                normalized.contains("ubs") ||
                normalized.contains("caps") -> {
                Pair(
                    "Procurar acompanhamento profissional é um gesto valioso de cuidado consigo. Você pode contar com a UBS, o CAPS, o CEREST (para questões ligadas ao trabalho), núcleos de apoio da sua instituição de ensino e clínicas-escola de Psicologia. Toque em 'Encontrar apoio profissional' abaixo para ver cada serviço em detalhes.",
                    true
                )
            }
            else -> {
                Pair(
                    "Obrigado por compartilhar um pouco do seu momento. Na rotina da saúde, nem sempre encontramos um espaço sem pressa e sem julgamentos para expressar o que sentimos. Lembre-se de que esta é uma simulação educativa, mas o seu bem-estar é muito real: acolha seu ritmo hoje e conte com as orientações e com a Rede de Apoio sempre que precisar.",
                    true
                )
            }
        }
    }
}
